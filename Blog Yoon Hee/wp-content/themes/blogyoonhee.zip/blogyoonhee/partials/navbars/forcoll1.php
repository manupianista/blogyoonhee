
<div class="wrapper">

<!-- Sidebar  -->
<nav id="sidebar">
            <div class="sidebar-header">
                
                <img src="http://www.yoonheefashion.info/wp-content/uploads/2019/05/4.png" class="img-fluid" alt="logo">
            </div>

            <ul class="list-unstyled components text-center">
                
                <li>
                    <a href="index.php">HOME</a>
                    
                </li>
                <li>
                    <a href="index.php/gallery">GALLERY</a>
                </li>
                <li class="active">
                    <a href="index.php/collection-no-1">COLLECTION NO. 1</a>
                </li>
                <li>
                     <a href="index.php/best-proyect">BEST PROYECT</a>
                </li>
                
                <li>
                    <a href="index.php/contact">CONTACT</a>
                </li>
                <li>
                    <i class="fab fa-instagram"></i>
                    <i class="fab fa-facebook"></i>


                </li>
                
            </ul>

          
        </nav>