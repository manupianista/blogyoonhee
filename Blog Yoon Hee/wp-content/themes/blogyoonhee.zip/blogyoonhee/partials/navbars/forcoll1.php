
<div class="wrapper">

<!-- Sidebar  -->
<nav id="sidebar">
            <div class="sidebar-header">
                
                <img src="http://www.yoonheefashion.info/wp-content/uploads/2019/05/4.png" class="img-fluid" alt="logo">
            </div>

            <ul class="list-unstyled components text-center">
                
                <li>
                    <a href="index.php/home">HOME</a>
                    
                </li>
                <li>
                    <a href="index.php/gallery">GALLERY</a>
                </li>
                <li class="active">
                    <a href="index.php/collection-no-1">COLLECTION NO. 1</a>
                </li>
                <li>
                     <a href="index.php/best-proyect">BEST PROJECTS</a>
                </li>
                
                <li>
                    <a href="index.php/contact">CONTACT</a>
                </li>
                <li>
                <a href="https://instagram.com/_yoonheekim?igshid=d5hbuzfl1zfu" target="_blank"><i class="fab fa-instagram"></i></a>
                   


                </li>
                
            </ul>

          
        </nav>