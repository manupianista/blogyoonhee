<!-- Sidebar  -->
<nav id="sidebar">
            <div class="sidebar-header">
                <h3>Yoon Hee</h3>
            </div>

            <ul class="list-unstyled components">
                
                <li class="active">
                    <a href="#homeSubmenu" data-toggle="collapse" aria-expanded="false" class="">HOME</a>
                    
                </li>
                <li>
                    <a href="#">GALLERY</a>
                </li>
                <li>
                    <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">COLLECTIONS</a>
                    <ul class="collapse list-unstyled" id="pageSubmenu">
                        <li>
                            <a href="#">COLLECTION NO. 1</a>
                        </li>
                        <li>
                            <a href="#">BEST PROYECT</a>
                        </li>
                        
                    </ul>
                </li>
                <li>
                    <a href="#">CONTACT</a>
                </li>
                
            </ul>

          
        </nav>