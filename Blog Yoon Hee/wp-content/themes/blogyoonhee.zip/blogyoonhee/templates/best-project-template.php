<?php 

/*
Template Name: bestprojects-template
*/

?>

<?php 
get_header(); 
get_template_part('partials/navbars/forbest');
?>

        
    
        <!-- Page Content  -->
        <div id="content">

            <?php get_template_part('partials/toggle'); ?>
            
        </div>
    </div>


     
<?php get_footer(); ?>