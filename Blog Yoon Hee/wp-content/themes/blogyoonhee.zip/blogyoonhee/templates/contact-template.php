<?php 

/*
Template Name: contact-template
*/

?>

<?php 
get_header(); 
get_template_part('partials/navbars/forcontact');
?>

        
    
        <!-- Page Content  -->
        <div id="content">

            <?php get_template_part('partials/toggle'); ?>
            
        </div>
    


    
    

<?php get_footer(); ?>