<?php 

/*
Template Name: collaborations-template
*/

?>

<?php 
get_header(); 
get_template_part('partials/navbars/forcollaborations');
?>

<!-- Page Content  -->

<div id="content">
    <?php get_template_part('partials/toggle'); ?> 
            
	<!--<div class="galerias"> -->
		<!-- Collaborations Content -->
	<!--	<section class="gallery-block cards-gallery">
			<div class="container">
				<div class="row">
					<div class="col-md-6 col-lg-4 pl-2 pr-2  py-3">
						<div class="card border-0 transform-on-hover">
							<a class="lightbox" href=" "><img src=" " class="card-img-top"></a>
						</div>
					</div>
					
					<div class="col-md-6 col-lg-4 pl-2 pr-2  py-3">
						<div class="card border-0 transform-on-hover">
							<a class="lightbox" href=" "><img src=" " class="card-img-top"></a>
						</div>
					</div>
					
					<div class="col-md-6 col-lg-4 pl-2 pr-2  py-3">
						<div class="card border-0 transform-on-hover">
							<a class="lightbox" href=" "><img src=" " class="card-img-top"></a>
						</div>
					</div>
					
					<div class="col-md-6 col-lg-4 pl-2 pr-2  py-3">
						<div class="card border-0 transform-on-hover">
							<a class="lightbox" href=" "><img src=" " class="card-img-top"></a>
						</div>
					</div>
					
					<div class="col-md-6 col-lg-4 pl-2 pr-2  py-3">
						<div class="card border-0 transform-on-hover">
							<a class="lightbox" href=" "><img src=" " class="card-img-top"></a>
						</div>
					</div>
				</div>
			</div>
		</section>
	</div>
</div>
-->

<!-- baguetteBox JS -->       
<script src="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.10.0/baguetteBox.min.js"></script>

<?php get_footer(); ?>
